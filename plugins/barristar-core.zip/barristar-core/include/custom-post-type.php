<?php

/**
 * Initialize Custom Post Type - Barristar Theme
 */

function barristar_custom_post_type() {

  $service_cpt = (barristar_framework_active()) ? cs_get_option('theme_service_name') : '';
  $service_slug = (barristar_framework_active()) ? cs_get_option('theme_service_slug') : '';
  $service_cpt_slug = (barristar_framework_active()) ? cs_get_option('theme_service_cat_slug') : '';

  $base = (isset($service_cpt_slug) && $service_cpt_slug !== '') ? sanitize_title_with_dashes($service_cpt_slug) : ((isset($service_cpt) && $service_cpt !== '') ? strtolower($service_cpt) : 'service');
  $base_slug = (isset($service_slug) && $service_slug !== '') ? sanitize_title_with_dashes($service_slug) : ((isset($service_cpt) && $service_cpt !== '') ? strtolower($service_cpt) : 'service');
  $label = ucfirst((isset($service_cpt) && $service_cpt !== '') ? strtolower($service_cpt) : 'service');

  // Register custom post type - Service
  register_post_type('service',
    array(
      'labels' => array(
        'name' => $label,
        'singular_name' => sprintf(esc_html__('%s Post', 'barristar-core' ), $label),
        'all_items' => sprintf(esc_html__('All %s', 'barristar-core' ), $label),
        'add_new' => esc_html__('Add New', 'barristar-core') ,
        'add_new_item' => sprintf(esc_html__('Add New %s', 'barristar-core' ), $label),
        'edit' => esc_html__('Edit', 'barristar-core') ,
        'edit_item' => sprintf(esc_html__('Edit %s', 'barristar-core' ), $label),
        'new_item' => sprintf(esc_html__('New %s', 'barristar-core' ), $label),
        'view_item' => sprintf(esc_html__('View %s', 'barristar-core' ), $label),
        'search_items' => sprintf(esc_html__('Search %s', 'barristar-core' ), $label),
        'not_found' => esc_html__('Nothing found in the Database.', 'barristar-core') ,
        'not_found_in_trash' => esc_html__('Nothing found in Trash', 'barristar-core') ,
        'parent_item_colon' => ''
      ) ,
      'public' => true,
      'publicly_queryable' => true,
      'exclude_from_search' => false,
      'show_ui' => true,
      'query_var' => true,
      'menu_position' => 10,
      'menu_icon' => 'dashicons-welcome-add-page',
      'rewrite' => array(
        'slug' => $base_slug,
        'with_front' => false
      ),
      'has_archive' => true,
      'capability_type' => 'post',
      'hierarchical' => true,
      'supports' => array(
        'title',
        'editor',
        'author',
        'thumbnail',
        'excerpt',
        'trackbacks',
        'custom-fields',
        'comments',
        'revisions',
        'sticky',
        'page-attributes'
      )
    )
  );
  // Registered

  // Add Category Taxonomy for our Custom Post Type - Service
  register_taxonomy(
    'service_category',
    'service',
    array(
      'hierarchical' => true,
      'public' => true,
      'show_ui' => true,
      'show_admin_column' => true,
      'show_in_nav_menus' => true,
      'labels' => array(
        'name' => sprintf(esc_html__( '%s Categories', 'barristar-core' ), $label),
        'singular_name' => sprintf(esc_html__('%s Category', 'barristar-core'), $label),
        'search_items' =>  sprintf(esc_html__( 'Search %s Categories', 'barristar-core'), $label),
        'all_items' => sprintf(esc_html__( 'All %s Categories', 'barristar-core'), $label),
        'parent_item' => sprintf(esc_html__( 'Parent %s Category', 'barristar-core'), $label),
        'parent_item_colon' => sprintf(esc_html__( 'Parent %s Category:', 'barristar-core'), $label),
        'edit_item' => sprintf(esc_html__( 'Edit %s Category', 'barristar-core'), $label),
        'update_item' => sprintf(esc_html__( 'Update %s Category', 'barristar-core'), $label),
        'add_new_item' => sprintf(esc_html__( 'Add New %s Category', 'barristar-core'), $label),
        'new_item_name' => sprintf(esc_html__( 'New %s Category Name', 'barristar-core'), $label)
      ),
      'rewrite' => array( 'slug' => $base . '_cat' ),
    )
  );

  $service_custom_taxonomies = (barristar_framework_active()) ? cs_get_option('service_custom_taxonomies') : '';
  $counter = 0;
  if ($service_custom_taxonomies) {
    foreach ($service_custom_taxonomies as $key => $custom_taxonomy) {
      $counter++;
      $heading = $custom_taxonomy['taxonomy_name'];
      $own_id = preg_replace('/[^a-z]/', "_", strtolower($heading));

      register_taxonomy(
        'service_'.$own_id,
        'service',
        array(
          'hierarchical' => true,
          'public' => true,
          'show_ui' => true,
          'show_admin_column' => true,
          'show_in_nav_menus' => true,
          'labels' => array(
            'name' => sprintf(esc_html__( '%s '.$heading, 'barristar-core' ), $label),
            'singular_name' => sprintf(esc_html__('%s '.$heading, 'barristar-core'), $label),
            'search_items' =>  sprintf(esc_html__( 'Search %s '.$heading, 'barristar-core'), $label),
            'all_items' => sprintf(esc_html__( 'All %s '.$heading, 'barristar-core'), $label),
            'parent_item' => sprintf(esc_html__( 'Parent %s '.$heading, 'barristar-core'), $label),
            'parent_item_colon' => sprintf(esc_html__( 'Parent %s :.$heading', 'barristar-core'), $label),
            'edit_item' => sprintf(esc_html__( 'Edit %s '.$heading, 'barristar-core'), $label),
            'update_item' => sprintf(esc_html__( 'Update %s '.$heading, 'barristar-core'), $label),
            'add_new_item' => sprintf(esc_html__( 'Add New %s '.$heading, 'barristar-core'), $label),
            'new_item_name' => sprintf(esc_html__( 'New %s '.$heading.' Name', 'barristar-core'), $label)
          ),
          'rewrite' => array( 'slug' => 'service_'.$own_id),
        )
      );
    }
  }


  // Project Start
  
  $project_cpt = (barristar_framework_active()) ? cs_get_option('theme_project_name') : '';
  $project_slug = (barristar_framework_active()) ? cs_get_option('theme_project_slug') : '';
  $project_cpt_slug = (barristar_framework_active()) ? cs_get_option('theme_project_cat_slug') : '';

  $base = (isset($project_cpt_slug) && $project_cpt_slug !== '') ? sanitize_title_with_dashes($project_cpt_slug) : ((isset($project_cpt) && $project_cpt !== '') ? strtolower($project_cpt) : 'project');
  $base_slug = (isset($project_slug) && $project_slug !== '') ? sanitize_title_with_dashes($project_slug) : ((isset($project_cpt) && $project_cpt !== '') ? strtolower($project_cpt) : 'project');
  $label = ucfirst((isset($project_cpt) && $project_cpt !== '') ? strtolower($project_cpt) : 'project');

  // Register custom post type - Project
  register_post_type('project',
    array(
      'labels' => array(
        'name' => $label,
        'singular_name' => sprintf(esc_html__('%s Post', 'barristar-core' ), $label),
        'all_items' => sprintf(esc_html__('All %s', 'barristar-core' ), $label),
        'add_new' => esc_html__('Add New', 'barristar-core') ,
        'add_new_item' => sprintf(esc_html__('Add New %s', 'barristar-core' ), $label),
        'edit' => esc_html__('Edit', 'barristar-core') ,
        'edit_item' => sprintf(esc_html__('Edit %s', 'barristar-core' ), $label),
        'new_item' => sprintf(esc_html__('New %s', 'barristar-core' ), $label),
        'view_item' => sprintf(esc_html__('View %s', 'barristar-core' ), $label),
        'search_items' => sprintf(esc_html__('Search %s', 'barristar-core' ), $label),
        'not_found' => esc_html__('Nothing found in the Database.', 'barristar-core') ,
        'not_found_in_trash' => esc_html__('Nothing found in Trash', 'barristar-core') ,
        'parent_item_colon' => ''
      ) ,
      'public' => true,
      'publicly_queryable' => true,
      'exclude_from_search' => false,
      'show_ui' => true,
      'query_var' => true,
      'menu_position' => 10,
      'menu_icon' => 'dashicons-portfolio',
      'rewrite' => array(
        'slug' => $base_slug,
        'with_front' => false
      ),
      'has_archive' => true,
      'capability_type' => 'post',
      'hierarchical' => true,
      'supports' => array(
        'title',
        'editor',
        'author',
        'thumbnail',
        'excerpt',
        'trackbacks',
        'custom-fields',
        'comments',
        'revisions',
        'sticky',
        'page-attributes'
      )
    )
  );
  // Registered

  // Add Category Taxonomy for our Custom Post Type - Project
  register_taxonomy(
    'project_category',
    'project',
    array(
      'hierarchical' => true,
      'public' => true,
      'show_ui' => true,
      'show_admin_column' => true,
      'show_in_nav_menus' => true,
      'labels' => array(
        'name' => sprintf(esc_html__( '%s Categories', 'barristar-core' ), $label),
        'singular_name' => sprintf(esc_html__('%s Category', 'barristar-core'), $label),
        'search_items' =>  sprintf(esc_html__( 'Search %s Categories', 'barristar-core'), $label),
        'all_items' => sprintf(esc_html__( 'All %s Categories', 'barristar-core'), $label),
        'parent_item' => sprintf(esc_html__( 'Parent %s Category', 'barristar-core'), $label),
        'parent_item_colon' => sprintf(esc_html__( 'Parent %s Category:', 'barristar-core'), $label),
        'edit_item' => sprintf(esc_html__( 'Edit %s Category', 'barristar-core'), $label),
        'update_item' => sprintf(esc_html__( 'Update %s Category', 'barristar-core'), $label),
        'add_new_item' => sprintf(esc_html__( 'Add New %s Category', 'barristar-core'), $label),
        'new_item_name' => sprintf(esc_html__( 'New %s Category Name', 'barristar-core'), $label)
      ),
      'rewrite' => array( 'slug' => $base . '_cat' ),
    )
  );

  $project_custom_taxonomies = (barristar_framework_active()) ? cs_get_option('project_custom_taxonomies') : '';
  $counter = 0;
  if ($project_custom_taxonomies) {
    foreach ($project_custom_taxonomies as $key => $custom_taxonomy) {
      $counter++;
      $heading = $custom_taxonomy['taxonomy_name'];
      $own_id = preg_replace('/[^a-z]/', "_", strtolower($heading));

      register_taxonomy(
        'project_'.$own_id,
        'project',
        array(
          'hierarchical' => true,
          'public' => true,
          'show_ui' => true,
          'show_admin_column' => true,
          'show_in_nav_menus' => true,
          'labels' => array(
            'name' => sprintf(esc_html__( '%s '.$heading, 'barristar-core' ), $label),
            'singular_name' => sprintf(esc_html__('%s '.$heading, 'barristar-core'), $label),
            'search_items' =>  sprintf(esc_html__( 'Search %s '.$heading, 'barristar-core'), $label),
            'all_items' => sprintf(esc_html__( 'All %s '.$heading, 'barristar-core'), $label),
            'parent_item' => sprintf(esc_html__( 'Parent %s '.$heading, 'barristar-core'), $label),
            'parent_item_colon' => sprintf(esc_html__( 'Parent %s :.$heading', 'barristar-core'), $label),
            'edit_item' => sprintf(esc_html__( 'Edit %s '.$heading, 'barristar-core'), $label),
            'update_item' => sprintf(esc_html__( 'Update %s '.$heading, 'barristar-core'), $label),
            'add_new_item' => sprintf(esc_html__( 'Add New %s '.$heading, 'barristar-core'), $label),
            'new_item_name' => sprintf(esc_html__( 'New %s '.$heading.' Name', 'barristar-core'), $label)
          ),
          'rewrite' => array( 'slug' => 'project_'.$own_id),
        )
      );
    }
  }




  // Attorney Start

  $attorney_cpt = (barristar_framework_active()) ? cs_get_option('theme_attorney_name') : '';
  $attorney_slug = (barristar_framework_active()) ? cs_get_option('theme_attorney_slug') : '';
  $attorney_cpt_slug = (barristar_framework_active()) ? cs_get_option('theme_attorney_cat_slug') : '';

  $base = (isset($attorney_cpt_slug) && $attorney_cpt_slug !== '') ? sanitize_title_with_dashes($attorney_cpt_slug) : ((isset($attorney_cpt) && $attorney_cpt !== '') ? strtolower($attorney_cpt) : 'attorney');
  $base_slug = (isset($attorney_slug) && $attorney_slug !== '') ? sanitize_title_with_dashes($attorney_slug) : ((isset($attorney_cpt) && $attorney_cpt !== '') ? strtolower($attorney_cpt) : 'attorney');
  $label = ucfirst((isset($attorney_cpt) && $attorney_cpt !== '') ? strtolower($attorney_cpt) : 'attorney');

  // Register custom post type - Attorney
  register_post_type('attorney',
    array(
      'labels' => array(
        'name' => $label,
        'singular_name' => sprintf(esc_html__('%s Post', 'barristar-core' ), $label),
        'all_items' => sprintf(esc_html__('All %s', 'barristar-core' ), $label),
        'add_new' => esc_html__('Add New', 'barristar-core') ,
        'add_new_item' => sprintf(esc_html__('Add New %s', 'barristar-core' ), $label),
        'edit' => esc_html__('Edit', 'barristar-core') ,
        'edit_item' => sprintf(esc_html__('Edit %s', 'barristar-core' ), $label),
        'new_item' => sprintf(esc_html__('New %s', 'barristar-core' ), $label),
        'view_item' => sprintf(esc_html__('View %s', 'barristar-core' ), $label),
        'search_items' => sprintf(esc_html__('Search %s', 'barristar-core' ), $label),
        'not_found' => esc_html__('Nothing found in the Database.', 'barristar-core') ,
        'not_found_in_trash' => esc_html__('Nothing found in Trash', 'barristar-core') ,
        'parent_item_colon' => ''
      ) ,
      'public' => true,
      'publicly_queryable' => true,
      'exclude_from_search' => false,
      'show_ui' => true,
      'query_var' => true,
      'menu_position' => 10,
      'menu_icon' => 'dashicons-groups',
      'rewrite' => array(
        'slug' => $base_slug,
        'with_front' => false
      ),
      'has_archive' => true,
      'capability_type' => 'post',
      'hierarchical' => true,
      'supports' => array(
        'title',
        'editor',
        'author',
        'thumbnail',
        'excerpt',
        'trackbacks',
        'custom-fields',
        'comments',
        'revisions',
        'sticky',
        'page-attributes'
      )
    )
  );
  // Registered

  // Add Category Taxonomy for our Custom Post Type - Attorney
  register_taxonomy(
    'attorney_category',
    'attorney',
    array(
      'hierarchical' => true,
      'public' => true,
      'show_ui' => true,
      'show_admin_column' => true,
      'show_in_nav_menus' => true,
      'labels' => array(
        'name' => sprintf(esc_html__( '%s Categories', 'barristar-core' ), $label),
        'singular_name' => sprintf(esc_html__('%s Category', 'barristar-core'), $label),
        'search_items' =>  sprintf(esc_html__( 'Search %s Categories', 'barristar-core'), $label),
        'all_items' => sprintf(esc_html__( 'All %s Categories', 'barristar-core'), $label),
        'parent_item' => sprintf(esc_html__( 'Parent %s Category', 'barristar-core'), $label),
        'parent_item_colon' => sprintf(esc_html__( 'Parent %s Category:', 'barristar-core'), $label),
        'edit_item' => sprintf(esc_html__( 'Edit %s Category', 'barristar-core'), $label),
        'update_item' => sprintf(esc_html__( 'Update %s Category', 'barristar-core'), $label),
        'add_new_item' => sprintf(esc_html__( 'Add New %s Category', 'barristar-core'), $label),
        'new_item_name' => sprintf(esc_html__( 'New %s Category Name', 'barristar-core'), $label)
      ),
      'rewrite' => array( 'slug' => $base . '_cat' ),
    )
  );

  $attorney_custom_taxonomies = (barristar_framework_active()) ? cs_get_option('attorney_custom_taxonomies') : '';
  $counter = 0;
  if ($attorney_custom_taxonomies) {
    foreach ($attorney_custom_taxonomies as $key => $custom_taxonomy) {
      $counter++;
      $heading = $custom_taxonomy['taxonomy_name'];
      $own_id = preg_replace('/[^a-z]/', "_", strtolower($heading));

      register_taxonomy(
        'attorney_'.$own_id,
        'attorney',
        array(
          'hierarchical' => true,
          'public' => true,
          'show_ui' => true,
          'show_admin_column' => true,
          'show_in_nav_menus' => true,
          'labels' => array(
            'name' => sprintf(esc_html__( '%s '.$heading, 'barristar-core' ), $label),
            'singular_name' => sprintf(esc_html__('%s '.$heading, 'barristar-core'), $label),
            'search_items' =>  sprintf(esc_html__( 'Search %s '.$heading, 'barristar-core'), $label),
            'all_items' => sprintf(esc_html__( 'All %s '.$heading, 'barristar-core'), $label),
            'parent_item' => sprintf(esc_html__( 'Parent %s '.$heading, 'barristar-core'), $label),
            'parent_item_colon' => sprintf(esc_html__( 'Parent %s :.$heading', 'barristar-core'), $label),
            'edit_item' => sprintf(esc_html__( 'Edit %s '.$heading, 'barristar-core'), $label),
            'update_item' => sprintf(esc_html__( 'Update %s '.$heading, 'barristar-core'), $label),
            'add_new_item' => sprintf(esc_html__( 'Add New %s '.$heading, 'barristar-core'), $label),
            'new_item_name' => sprintf(esc_html__( 'New %s '.$heading.' Name', 'barristar-core'), $label)
          ),
          'rewrite' => array( 'slug' => 'attorney_'.$own_id),
        )
      );
    }
  }


}




// After Theme Setup
function barristar_custom_flush_rules() {
  // Enter post type function, so rewrite work within this function
  barristar_custom_post_type();
  // Flush it
  flush_rewrite_rules();
}
register_activation_hook(__FILE__, 'barristar_custom_flush_rules');
add_action('init', 'barristar_custom_post_type');


/* ---------------------------------------------------------------------------
 * Custom columns - Service
 * --------------------------------------------------------------------------- */
add_filter("manage_edit-service_columns", "barristar_service_edit_columns");
function barristar_service_edit_columns($columns) {
  $new_columns['cb'] = '<input type="checkbox" />';
  $new_columns['title'] = esc_html__('Title', 'barristar-core' );
  $new_columns['thumbnail'] = esc_html__('Image', 'barristar-core' );
  $new_columns['date'] = esc_html__('Date', 'barristar-core' );

  return $new_columns;
}

add_action('manage_service_posts_custom_column', 'barristar_manage_service_columns', 10, 2);
function barristar_manage_service_columns( $column_name ) {
  global $post;

  switch ($column_name) {

    /* If displaying the 'Image' column. */
    case 'thumbnail':
      echo get_the_post_thumbnail( $post->ID, array( 100, 100) );
    break;

    /* Just break out of the switch statement for everything else. */
    default :
      break;
    break;

  }
}


/* ---------------------------------------------------------------------------
 * Custom columns - case
 * --------------------------------------------------------------------------- */
add_filter("manage_edit-project_columns", "barristar_project_edit_columns");
function barristar_project_edit_columns($columns) {
  $new_columns['cb'] = '<input type="checkbox" />';
  $new_columns['title'] = esc_html__('Title', 'barristar-core' );
  $new_columns['thumbnail'] = esc_html__('Image', 'barristar-core' );
  $new_columns['date'] = esc_html__('Date', 'barristar-core' );

  return $new_columns;
}

add_action('manage_project_posts_custom_column', 'barristar_manage_project_columns', 10, 2);
function barristar_manage_project_columns( $column_name ) {
  global $post;

  switch ($column_name) {

    /* If displaying the 'Image' column. */
    case 'thumbnail':
      echo get_the_post_thumbnail( $post->ID, array( 100, 100) );
    break;

    /* Just break out of the switch statement for everything else. */
    default :
      break;
    break;

  }
}


// Attorney Slug
function barristar_custom_attorney_slug() {
  $attorney_cpt = (barristar_framework_active()) ? cs_get_option('theme_attorney_name') : '';
  if ($attorney_cpt === '') $attorney_cp = 'attorney';
  $rules = get_option( 'rewrite_rules' );
  if ( ! isset( $rules['('.$attorney_cpt.')/(\d*)$'] ) ) {
    global $wp_rewrite;
    $wp_rewrite->flush_rules();
  }
}
add_action( 'cs_validate_save_after','barristar_custom_attorney_slug' );


// Avoid attorney post type as 404 page while it change
function thx_cpt_avoid_error_attorney() {
  $attorney_cpt = (barristar_framework_active()) ? cs_get_option('theme_attorney_name') : '';
  if ($attorney_cpt === '') $attorney_cp = 'attorney';
  $set = get_option('post_type_rules_flased_' . $attorney_cpt);
  if ($set !== true){
    flush_rewrite_rules(false);
    update_option('post_type_rules_flased_' . $attorney_cpt,true);
  }
}
add_action('init', 'thx_cpt_avoid_error_attorney');

// Add Filter by Category in Attorney Type
add_action('restrict_manage_posts', 'barristar_filter_attorney_categories');
function barristar_filter_attorney_categories() {
  global $typenow;
  $post_type = 'attorney'; // Attorney post type
  $taxonomy  = 'attorney_category'; // Attorney category taxonomy
  if ($typenow == $post_type) {
    $selected      = isset($_GET[$taxonomy]) ? $_GET[$taxonomy] : '';
    $info_taxonomy = get_taxonomy($taxonomy);
    wp_dropdown_categories(array(
      'show_option_all' => sprintf(esc_html__("Show All %s", 'barristar-core'), $info_taxonomy->label),
      'taxonomy'        => $taxonomy,
      'name'            => $taxonomy,
      'orderby'         => 'name',
      'selected'        => $selected,
      'show_count'      => true,
      'hide_empty'      => true,
    ));
  };
}

// Attorney Search => ID to Term
add_filter('parse_query', 'barristar_attorney_id_term_search');
function barristar_attorney_id_term_search($query) {
  global $pagenow;
  $post_type = 'attorney'; // Attorney post type
  $taxonomy  = 'attorney_category'; // Attorney category taxonomy
  $q_vars    = &$query->query_vars;
  if ( $pagenow == 'edit.php' && isset($q_vars['post_type']) && $q_vars['post_type'] == $post_type && isset($q_vars[$taxonomy]) && is_numeric($q_vars[$taxonomy]) && $q_vars[$taxonomy] != 0 ) {
    $term = get_term_by('id', $q_vars[$taxonomy], $taxonomy);
    $q_vars[$taxonomy] = $term->slug;
  }
}

/* ---------------------------------------------------------------------------
 * Custom columns - Attorney
 * --------------------------------------------------------------------------- */
add_filter("manage_edit-attorney_columns", "barristar_attorney_edit_columns");
function barristar_attorney_edit_columns($columns) {
  $new_columns['cb'] = '<input type="checkbox" />';
  $new_columns['title'] = __('Title', 'barristar-core' );
  $new_columns['thumbnail'] = __('Image', 'barristar-core' );
  $new_columns['attorney_category'] = __('Categories', 'barristar-core' );
  $new_columns['attorney_order'] = __('Order', 'barristar-core' );
  $new_columns['date'] = __('Date', 'barristar-core' );

  return $new_columns;
}
add_action('manage_attorney_posts_custom_column', 'barristar_manage_attorney_columns', 10, 2);
function barristar_manage_attorney_columns( $column_name ) {
  global $post;

  switch ($column_name) {

    /* If displaying the 'Image' column. */
    case 'thumbnail':
      echo get_the_post_thumbnail( $post->ID, array( 100, 100) );
    break;

    /* If displaying the 'Categories' column. */
    case 'attorney_category' :

      $terms = get_the_terms( $post->ID, 'attorney_category' );

      if ( !empty( $terms ) ) {

        $out = array();
        foreach ( $terms as $term ) {
            $out[] = sprintf( '<a href="%s">%s</a>',
              esc_url( add_query_arg( array( 'post_type' => $post->post_type, 'attorney_category' => $term->slug ), 'edit.php' ) ),
              esc_html( sanitize_term_field( 'name', $term->name, $term->term_id, 'attorney_category', 'display' ) )
            );
        }
        /* Join the terms, separating them with a comma. */
        echo join( ', ', $out );
      }

      /* If no terms were found, output a default message. */
      else {
        echo '&macr;';
      }

    break;

    case "attorney_order":
      echo $post->menu_order;
    break;

    /* Just break out of the switch statement for everything else. */
    default :
      break;
    break;

  }
}
