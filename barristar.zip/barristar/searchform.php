<div class="search-widget">
   <form method="get" id="searchform" action="<?php echo esc_url( home_url('/') ); ?>" class="searchform" >
        <div>
           <input type="text" name="s" id="s2" placeholder="<?php echo esc_attr__( 'Search...','barristar' ); ?>">
            <button type="submit"><i class="ti-search"></i></button>
        </div>
    </form>
</div>
